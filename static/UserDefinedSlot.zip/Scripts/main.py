import ems
import numpy as np

stator_inner_radius = 80.95e-3  # m
n_slots = 48

opening_width = 2e-3  # m
opening_height = 1e-3  # m

wedge_height = 1e-3  # m

slot_width = 5e-3  # m
slot_hight = 30e-3  # m

fillet_radius = 2.5e-3  # m

p1_y = -opening_width / 2
p1_x = np.sqrt(stator_inner_radius**2 - p1_y**2)

p2_x = p1_x + opening_height
p2_y = p1_y

p3_x = p2_x + wedge_height
p3_y = p2_y - slot_width / 2

p4_x = p3_x + slot_hight / 2
p4_y = p3_y

p5_x = p4_x + slot_hight / 2
p5_y = p4_y

p6_x = p5_x
p6_y = 0

pts = {
    "points": {
        "1": (p1_x, p1_y),
        "2": (p2_x, p2_y),
        "3": (p3_x, p3_y),
        "4": (p4_x, p4_y),
        "5": (p5_x, p5_y),
        "6": (p6_x, p6_y),
        "7": (p5_x, -p5_y),
        "8": (p4_x, -p4_y),
        "9": (p3_x, -p3_y),
        "10": (p2_x, -p2_y),
        "11": (p1_x, -p1_y),
        "12": (p3_x, 0),
        "13": (p4_x, 0),
    },
    "opening_top_index": "11",
    "opening_bottom_index": "1",
    "middle_bottom_index": "6",
    "middle_top_index": "12",
    "center_index": "13",
}

cns = {
    "slot": [
        ("line", "1", "2"),
        ("line", "2", "3"),
        ("line", "3", "4"),
        ("fillet", "4", "5", "6", fillet_radius),
        ("line", "6", "7"),
        ("line", "7", "8"),
        ("line", "8", "9"),
        ("line", "9", "10"),
        ("line", "10", "11"),
        ("line", "11", "1"),
    ],
    "wedge": [
        ("line", "1", "2"),
        ("line", "2", "3"),
        ("line", "3", "12"),
        ("line", "12", "9"),
        ("line", "9", "10"),
        ("line", "10", "11"),
        ("line", "11", "1"),
    ],
    "single_layer_winding": [
        ("line", "3", "4"),
        ("fillet", "4", "5", "6", fillet_radius),
        ("line", "6", "7"),
        ("line", "7", "8"),
        ("line", "8", "9"),
        ("line", "9", "12"),
        ("line", "12", "3"),
    ],
    "top_winding": [
        ("line", "3", "4"),
        ("line", "4", "13"),
        ("line", "13", "8"),
        ("line", "8", "9"),
        ("line", "9", "12"),
        ("line", "12", "3"),
    ],
    "bottom_winding": [
        ("fillet", "4", "5", "6", fillet_radius),
        ("line", "6", "7"),
        ("line", "7", "8"),
        ("line", "8", "13"),
        ("line", "13", "4"),
    ],
    "left_winding": [
        ("line", "3", "4"),
        ("fillet", "4", "5", "6", fillet_radius),
        ("line", "6", "13"),
        ("line", "13", "12"),
        ("line", "12", "3"),
    ],
    "right_winding": [
        ("line", "12", "13"),
        ("line", "13", "6"),
        ("line", "6", "7"),
        ("line", "7", "8"),
        ("line", "8", "9"),
        ("line", "9", "12"),
    ],
}


ems.update_parameters(
    {
        "stator_inner_radius": stator_inner_radius,
        "n_slots": n_slots,
        "pts": pts,
        "cns": cns,
    }
)
