import ems

H0 = 65e-3  # m
H1 = 4e-3  # m
H2 = 5e-3  # m
W0 = 2e-3  # m
W1 = 20e-3  # m
W2 = 10e-3  # m
R0 = 1e-3  # m
R1 = 3e-3  # m

point_a_x = H0 + H1 / 2
point_a_y = W0 / 2

point_b_x = H0
point_b_y = W0 / 2

point_c_x = H0
point_c_y = point_b_y + W2

point_d_x = H0
point_d_y = point_b_y + W1 + H1

point_e_x = H0 + H1 + H2
point_e_y = point_d_y

point_f_x = point_e_x + H1 / 2
point_f_y = point_e_y - H1 / 2

point_g_x = point_e_x
point_g_y = point_e_y - H1

point_h_x = H0 + H1
point_h_y = point_g_y

point_i_x = point_c_x + H1
point_i_y = point_c_y

point_j_x = point_b_x + H1
point_j_y = point_b_y

point_k_x = point_e_x
point_k_y = point_e_y - H1 / 2

point_x_x = H0
point_x_y = 0

pts = {
    "pole_top_index": "x",
    "pole_bottom_index": "x",
    "points": {
        "a_top": (point_a_x, point_a_y),
        "b_top": (point_b_x, point_b_y),
        "c_top": (point_c_x, point_c_y),
        "d_top": (point_d_x, point_d_y),
        "e_top": (point_e_x, point_e_y),
        "f_top": (point_f_x, point_f_y),
        "g_top": (point_g_x, point_g_y),
        "h_top": (point_h_x, point_h_y),
        "i_top": (point_i_x, point_i_y),
        "j_top": (point_j_x, point_j_y),
        "k_top": (point_k_x, point_k_y),
        "a_bottom": (point_a_x, -point_a_y),
        "b_bottom": (point_b_x, -point_b_y),
        "c_bottom": (point_c_x, -point_c_y),
        "d_bottom": (point_d_x, -point_d_y),
        "e_bottom": (point_e_x, -point_e_y),
        "f_bottom": (point_f_x, -point_f_y),
        "g_bottom": (point_g_x, -point_g_y),
        "h_bottom": (point_h_x, -point_h_y),
        "i_bottom": (point_i_x, -point_i_y),
        "j_bottom": (point_j_x, -point_j_y),
        "k_bottom": (point_k_x, -point_k_y),
        "x": (point_b_x, point_x_y),
    },
}

cns = {
    "holes": [
        [
            ("fillet", "a_top", "b_top", "c_top", R0),
            ("fillet", "c_top", "d_top", "e_top", R1 + H1),
            ("arc", "e_top", "k_top", "f_top"),
            ("arc", "f_top", "k_top", "g_top"),
            ("fillet", "g_top", "h_top", "i_top", R1),
            ("fillet", "i_top", "j_top", "a_top", R0),
        ],
        [
            ("fillet", "c_bottom", "b_bottom", "a_bottom", R0),
            ("fillet", "a_bottom", "j_bottom", "i_bottom", R0),
            ("fillet", "i_bottom", "h_bottom", "g_bottom", R1),
            ("arc", "g_bottom", "k_bottom", "f_bottom"),
            ("arc", "f_bottom", "k_bottom", "e_bottom"),
            ("fillet", "e_bottom", "d_bottom", "c_bottom", R1 + H1),
        ],
    ],
    "magnets": [
        [
            ("fillet", "a_top", "b_top", "c_top", R0),
            ("line", "c_top", "i_top"),
            ("fillet", "i_top", "j_top", "a_top", R0),
        ],
        [
            ("fillet", "a_bottom", "b_bottom", "c_bottom", R0),
            ("line", "c_bottom", "i_bottom"),
            ("fillet", "i_bottom", "j_bottom", "a_bottom", R0),
        ],
    ],
}

mgs = [
    {"coordination": "cartesian", "starting_point": "c_top", "ending_point": "i_top"},
    {
        "coordination": "cartesian",
        "starting_point": "c_bottom",
        "ending_point": "i_bottom",
    },
]

ems.update_parameters(
    {
        "pts": pts,
        "cns": cns,
        "mgs": mgs,
    }
)
