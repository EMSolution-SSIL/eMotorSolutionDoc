import ems
import numpy as np

stator_inner_radius = 80.2e-3  # m
n_poles = 8

h0 = 10e-3  # m
w0 = 40e-3  # m
h1 = 2e-3  # m
h2 = 5e-3  # m

pole_pitch = 2 * np.pi / n_poles

pa_x = stator_inner_radius * np.cos(pole_pitch / 2)
pa_y = stator_inner_radius * np.sin(pole_pitch / 2)

pb_x = stator_inner_radius - h0
pb_y = pb_x * np.tan(pole_pitch / 2)

pc_x = pb_x
pc_y =  w0 / 2

pd_x = pc_x - h1
pd_y = pc_y

pe_x = pd_x
pe_y = 0

pf_x = pe_x + h1 + h2
pf_y = 0

pg_x = pf_x
pg_y = pc_y
pts = {
    "points": {
        "a_top": (pa_x, pa_y),
        "b_top": (pb_x, pb_y),
        "c_top": (pc_x, pc_y),
        "d_top": (pd_x, pd_y),
        "e": (pe_x, pe_y),
        "f": (pf_x, pf_y),
        "g_top": (pg_x, pg_y),
        "a_bottom": (pa_x, -pa_y),
        "b_bottom": (pb_x, -pb_y),
        "c_bottom": (pc_x, -pc_y),
        "d_bottom": (pd_x, -pd_y),
        "g_bottom": (pg_x, -pg_y),
        "center": (0, 0),
    },
    "pole_top_index": "f",
    "pole_bottom_index": "e",
    "core_radius_index": "e",
}

cns = {
    "slots": [
        [  
            ("line", "a_top", "b_top"),
            ("line", "b_top", "c_top"),
            ("line", "c_top", "d_top"),
            ("line", "d_top", "e"),
            ("line", "e", "d_bottom"),
            ("line", "d_bottom", "c_bottom"),
            ("line", "c_bottom", "b_bottom"),
            ("line", "b_bottom", "a_bottom"),
            ("arc", "a_bottom", "center", "a_top"),
        ]
    ],
    "magnets": [
        [
            ("line", "c_top", "d_top"),
            ("line", "d_top", "e"),
            ("line", "e", "d_bottom"),
            ("line", "d_bottom", "c_bottom"),
            ("line", "c_bottom", "g_bottom"),
            ("line", "g_bottom", "f"),
            ("line", "f", "g_top"),
            ("line", "g_top", "c_top"),
        ]
    ]                  
}

mgs = [
    {
        "coordination": "cartesian",
        "starting_point": "e",
        "ending_point": "f",
    },
]  

ems.update_parameters(
    {
        "pts": pts,
        "cns": cns,
        "mgs": mgs,
    }
)